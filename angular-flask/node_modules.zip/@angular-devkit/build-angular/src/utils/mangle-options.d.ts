export declare const manglingDisabled: boolean;
